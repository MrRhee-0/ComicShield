# ComicShield

ComicShield is a separate Chrome Manifest V3 extension for `comix.to`. It hides or neutralizes deceptive ad and click-trap surfaces while preserving comic panels, browse filters, the long-strip reader, same-site chapter navigation, and reader controls. Version 0.2.2 repairs `/browse` advanced filter admission while preserving the v0.2.1 reader controller, requestAnimationFrame autoscroll, and reader-width zoom.

## Placement

Created at:

```text
C:\ARCANE_CODEX\RESEARCH\TCT_Derivations_and_Research\ShortsNuker\ComicShield
```

ComicShield is a sibling folder. It does not share code with the existing `ShortsNuker` extension folder.

## Permissions

Manifest permissions:

```json
{
  "permissions": ["storage"],
  "host_permissions": [
    "https://comix.to/*",
    "https://*.comix.to/*"
  ]
}
```

No background service worker is used. No remote code is used.

## Reconnaissance Findings

Live read-only inspection was performed on June 16, 2026.

Homepage:

- Normal structure: `#app-root`, `header.topnav`, `main.layout.layout--top`, `.main-col`, `.side-col`, `.section`, `.grid-updates`, `.card`.
- Same-site detail links: card links such as `a.card[href^="/title/"]`.
- Primary click trap: `html > body > a[href="#"][target="_blank"]`, fixed, transparent, full viewport, z-index `9999999`.
- Iframe candidate: `html > body > iframe`, 1x1/hidden/no visible source. Treated as an iframe outside the reader.
- External candidates observed: Discord links in sidebar/footer. These are preserved unless they become structurally ad-like.

Comic/detail page:

- Normal structure: `main.layout.layout--single`, `article.mpage`, `.mpage__hero`, `.mpage__poster-actions`, `.mpage__chapters`, `.mchap-list`, `.mchap-row`, `.mchap-row__primary`.
- Real chapter links: `.mchap-row__primary` same-site URLs such as `/title/.../10093636-chapter-64`.
- Primary click trap repeated: `html > body > a[href="#"][target="_blank"]`, fixed, transparent, full viewport, z-index `9999999`.
- External metadata candidates: `.mpage__chip--tracker` links to AniList, MAL, MangaUpdates, MangaDex, and related metadata sites. These are classified as safe external frontier, not ads.

Reader page:

- Reader root: `.rpage.rpage--long-strip.rpage--ttb.rpage--pb-left`.
- Scroll container: `.rpage-main.rpage-main--long-strip`, internal scroll height observed near 95,143 px.
- Panel container: `.rpage-main__inner > .rpage-page`.
- Comic image selector: `.rpage-page__img`.
- Reader controls: `.rpage-floatctl`, `.rpage-progress`, `.rpage-progress__seg`, `.rpage-cmpanel`.
- Primary click trap repeated: `html > body.rpage-body > a[href="#"][target="_blank"]`, fixed, transparent, full viewport, z-index `9999999`.
- Hit testing showed the trap was the top target at reader and empty-space viewport points.
- No visible iframes or external-domain anchors were observed on the reader page.

## Implemented Relations

Admitted reader surface:

- `.rpage`
- `.rpage-main`
- `.rpage-main__inner`
- `.rpage-page`
- `.rpage-page__img`

Admitted reader controls:

- `[data-comicshield-controller]`
- `.rpage-progress`
- `.rpage-progress__seg`
- `.rpage-floatctl`
- `.rpage-cmpanel`
- `.rpage-cmpanel__chapnav`
- `[aria-label="Reader controls"]`
- `[aria-label="Page progress"]`

Admitted chapter/navigation controls:

- `.mchap-row__primary`
- `.mchap-row a[href]`
- `.mpage__read`
- `.mpage__chapters a[href]`
- same-site chapter URLs containing `-chapter-`

Admitted browse filter controls on `/browse`:

- Route gate: `location.pathname` must resolve to `/browse`.
- Filter label relation: the filter panel must contain at least two of `Genres`, `Release Status`, `Demographic`, `Types`, `Content Rating`, and `Sort By`.
- Panel candidates: `form[action*="/browse"]`, `form`, `[class*="advanced" i]`, `[class*="filter" i]`, `[class*="search" i]`, `[class*="browse" i]`, `.panel`, `.section`.
- Real controls: `select`, `option`, `input`, `button`, `label`, `textarea`, same-site `a[href]`, role-based options/listboxes/combobox/menuitems, `aria-haspopup`, `aria-expanded`, `tabindex`, `data-value`, `data-key`, `data-id`, `data-name`, and dropdown/select/filter/menu/option class relations inside the admitted panel.
- Admitted controls are marked with `data-comicshield-browse-filter-admitted="true"` as they are encountered.

Excluded ad/click-trap surface:

- `body > a[href="#"][target="_blank"]` when fixed, empty, and large enough to cover the viewport.
- `iframe` elements outside the reader when hidden/tiny/no source or ad-host related.
- Large transparent positioned clickable surfaces outside admitted reader/native surfaces.
- Sticky/floating positioned surfaces outside admitted reader/native surfaces when structurally ad-like.
- External anchors outside admitted surfaces only when ad-host, empty/large/blank, or suspicious by relation.
- Inline popup handler surfaces containing `window.open`, popup/popunder language, or direct location redirects.

Boundary:

- Same-site reader and chapter navigation is allowed.
- Same-site `/browse` advanced filter controls are allowed before empty-space click-trap classification.
- Comic image/panel clicks are allowed when not routed through an excluded overlay.
- ComicShield-owned controller clicks are allowed through `[data-comicshield-controller]` before overlay/ad classification.
- The capture guard immediately returns for events whose target or composed path is inside `[data-comicshield-controller]`; it does not preventDefault, stopPropagation, or stopImmediatePropagation for controller events.
- The capture guard also immediately returns for admitted `/browse` filter controls and does not preventDefault, stopPropagation, or stopImmediatePropagation for those filter events.
- Empty non-interactive clicks on background surfaces are blocked in capture phase to prevent page-level popup handlers.
- Ambiguous external metadata links are preserved as debug frontier instead of hidden.

## Reader Controller

Injected controller surface:

- Host element: `[data-comicshield-controller="true"]`.
- Placement: fixed lower-right by default, z-index `2147483646`, draggable from the header.
- Shadow DOM is used for controller styling and controls so page CSS does not reshape it.
- The host is admitted as both a reader control and native site surface, so the existing MutationObserver scanner does not hide it as a floating/sticky ad.

Controller UI controls:

- Autoscroll play/pause.
- Autoscroll speed down.
- Autoscroll speed up.
- Autoscroll speed slider, 20 to 600 pixels per second.
- Reader zoom out.
- Reader zoom in.
- Reader zoom reset to 100%.
- Collapse/open controller.

Popup settings added:

- Show reader controller.
- Enable autoscroll controls.
- Enable reader zoom controls.
- Remember autoscroll speed.
- Remember reader zoom.
- Resume autoscroll on reader pages. This is off by default.

Storage keys in `chrome.storage.local` under `comicShieldSettings`:

- `showReaderController`
- `enableAutoscrollControls`
- `enableReaderZoomControls`
- `rememberAutoscrollSpeed`
- `rememberReaderZoom`
- `resumeAutoscroll`
- `controllerCollapsed`
- `autoscrollSpeed`
- `readerZoom`
- `autoscrollActive`

Scroll target relation:

1. Build candidate elements in this order: `document.scrollingElement`, `document.documentElement`, `document.body`, `.rpage-main`, `.rpage`, `.rpage-main__inner`.
2. Deduplicate candidates.
3. Return a typed packet: `type: "window"` for real document scrolling or `type: "element"` for internal reader scrolling.
4. `window` packets use `window.scrollBy({ top: delta, left: 0, behavior: "auto" })`.
5. `element` packets use `element.scrollTop += delta` only when `scrollHeight - clientHeight > 2` and `overflow-y` is not `hidden` or `clip`.
6. If a window packet reports a range but does not move, autoscroll switches to internal reader candidates.
7. Autoscroll uses `requestAnimationFrame`, advances by `autoscrollSpeed * dt`, caps at the bottom, and stops automatically at the bottom.

Zoom target relation:

1. Resolve `.rpage-main__inner`, `.rpage-main__inner > .rpage-page`, `.rpage-page`, and `.rpage-page__img`.
2. Measure the first visible page/image width as the base reader width before applying extension zoom.
3. For zoom values other than 100%, set CSS variables on `document.documentElement` and inject `#comicshield-reader-zoom-style`.
4. Apply width-based zoom to `.rpage-page`, cap it with `calc(100vw - 72px)`, center pages, and set images to `width: 100%`.
5. Reset to 100% removes the injected zoom style and CSS variables.
6. The zoom CSS does not set overflow on `html`, `body`, `.rpage`, or `.rpage-main`.

## What Is Hidden

- Full-viewport empty `body > a[href="#"][target="_blank"]` click traps.
- Hidden/tiny iframes outside the reader.
- Sticky/floating ad-like bars outside admitted reader/native surfaces.
- Strict visible ad-label surfaces outside admitted reader/native surfaces.

## What Is Pointer-Disabled

- Large transparent positioned click surfaces outside admitted reader/native surfaces.
- Suspicious external ad links outside admitted reader/native surfaces.
- Inline popup-handler surfaces that are not admitted reader controls.

## Blocked Events

When ComicShield is enabled and Protect reader clicks is on, the content script blocks in capture phase:

- `click`
- `mousedown`
- `mouseup`
- `pointerdown`
- `pointerup`
- `input`
- `change`
- `keydown`

Events are blocked when the target or composed path contains:

- known full-viewport empty click traps
- large transparent click surfaces
- suspicious external ad links
- inline popup-handler surfaces
- empty non-interactive background clicks on reader/site layout surfaces

The guard allows:

- `[data-comicshield-controller]`
- admitted `/browse` filter controls marked or detected by the route-specific filter relation
- `.rpage*` controls
- `.rpage-page` and `.rpage-page__img`
- same-site anchors
- same-site chapter links
- ordinary buttons, inputs, selects, tabs, and menus that are not classified as deceptive surfaces

## Unresolved Frontier

- External metadata links on detail pages are not treated as ads unless their structure changes into a suspicious ad relation.
- External community links, such as Discord, are preserved unless they are wrapped in an ad-like or deceptive surface.
- `/browse` filter menus appended outside the filter panel are admitted only when the page has a detected filter panel and the target has a dropdown/select/menu/option relation; external anchors and `target="_blank"` anchors remain excluded.
- Dynamically injected surfaces that do not meet the known trap, iframe, external-ad, high-z transparent, sticky/floating, or popup-handler relations are logged only when Debug mode is enabled.

## Load Unpacked in Chrome

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click Load unpacked.
4. Select:

```text
C:\ARCANE_CODEX\RESEARCH\TCT_Derivations_and_Research\ShortsNuker\ComicShield
```

## Release

Release ZIP:

```text
C:\ARCANE_CODEX\RESEARCH\TCT_Derivations_and_Research\ShortsNuker\ComicShield\release\ComicShield-v0.2.2.zip
```

## Safety Boundaries

- Does not scrape comic content.
- Does not download comic content.
- Does not bypass login or paywall systems.
- Does not click ad links.
- Does not open suspicious popup targets.
- Does not change browser security settings.
- Does not change Norton or security software settings.
- Does not modify ShortsNuker logic.
